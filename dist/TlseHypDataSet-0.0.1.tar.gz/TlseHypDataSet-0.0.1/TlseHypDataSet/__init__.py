"""
A Python library to use and analyse the Toulouse Hyperspectral Data Set.

"""

__version__ = "0.0.1"
__author__ = "Romain Thoreau"


