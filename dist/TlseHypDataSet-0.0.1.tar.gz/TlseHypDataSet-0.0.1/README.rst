Toulouse Hyperspectral Data Set
===============================

**TlseHypDataSet** is a Python library to flexibly load `PyTorch <https://pytorch.org/>`_ datasets and run machine learning experiments on the `Toulouse Hyperspectral Data Set <www.toulouse-hyperspectral-data-set.com>`_. 

